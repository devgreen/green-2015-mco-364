package green.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JTextArea;

public class ClientForGui {

	private BufferedReader reader;
	private PrintWriter writer;
	private JTextArea area;
	SocketThread thread;

	public ClientForGui(JTextArea area) throws UnknownHostException, IOException {
		Socket socket = new Socket("localhost", 1111);
		this.area = area;
		/*OutputStream out = socket.getOutputStream();
		writer = new PrintWriter(out, true);
		InputStream in = socket.getInputStream();
		reader = new BufferedReader(new InputStreamReader(in));*/
if (socket != null){
		thread = new SocketThread(socket, area);
		thread.start();
}
	}

	public BufferedReader getReader() {
		return reader;
	}

	public PrintWriter getWriter() {
		return writer;
	}

}
