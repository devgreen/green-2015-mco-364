package green.paint;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public abstract class BrushListener implements MouseListener, MouseMotionListener {

	private Canvas canvas;
	protected int startX;
	protected int startY;
	protected int endX;
	protected int endY;
	protected Point mousePressed;
	protected Point mouseDragged;

	public BrushListener(Canvas canvas) {
		this.canvas = canvas;
	}

	@Override
	public void mouseDragged(MouseEvent event) {
		mouseDragged = event.getPoint();
		//endX = event.getX();
		//endY = event.getY();
		canvas.repaint();

	}

	@Override
	public void mouseMoved(MouseEvent event) {

	}

	@Override
	public void mouseClicked(MouseEvent event) {

	}

	@Override
	public void mouseEntered(MouseEvent event) {

	}

	@Override
	public void mouseExited(MouseEvent event) {

	}

	@Override
	public void mousePressed(MouseEvent event) {
		mousePressed = event.getPoint();
		//startX = event.getX();
		//startY = event.getY();
		//canvas.repaint();

	}

	@Override
	public void mouseReleased(MouseEvent event) {
		draw(canvas.getImage().getGraphics());
		//canvas.repaint();

	}
	
	public abstract void draw(Graphics g);

}
